export const faqData = [
  {
    id: 1,
    question: 'What is the primary role of a business agency?',
    answer:
      'When collaborating with a business agency, you can generally expect an extensive array of services designed to not only support your current operations but also to foster growth and innovation within your business. These services often include strategic planning, marketing solutions, financial consulting, and operational improvements.',
  },
  {
    id: 2,
    question: 'What kinds of services should I anticipate from a business agency?',
    answer:
      'When collaborating with a business agency, you can generally expect an extensive array of services designed to not only support your current operations but also to foster growth and innovation within your business. These services often include strategic planning, marketing solutions, financial consulting, and operational improvements.',
  },
  {
    id: 3,
    question: 'How often should I consider updating my website?',
    answer:
      'When collaborating with a business agency, you can generally expect an extensive array of services designed to not only support your current operations but also to foster growth and innovation within your business. These services often include strategic planning, marketing solutions, financial consulting, and operational improvements.',
  },
  {
    id: 4,
    question: 'How often is it recommended to refresh my website?',
    answer:
      'When collaborating with a business agency, you can generally expect an extensive array of services designed to not only support your current operations but also to foster growth and innovation within your business. These services often include strategic planning, marketing solutions, financial consulting, and operational improvements.',
  },
];
