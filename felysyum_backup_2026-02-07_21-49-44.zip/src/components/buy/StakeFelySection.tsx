import RevealAnimation from '../animation/RevealAnimation';
import arrowUpRight from '@public/images/icons/arrow-up-right.svg'; // Assuming this exists, else will just use text or generic icon
import Image from 'next/image';

const StakeFelySection = () => {
    // Mock Data for the Table
    const stakeData = [
        { orderNo: '7399', capital: '2816.90', interest: '422.54', stakeId: '0', tx: '', status: 'Locked', date: '2025-12-08' },
        { orderNo: '7429', capital: '2817.00', interest: '422.55', stakeId: '0', tx: '', status: 'Locked', date: '2025-12-08' },
        { orderNo: '8080', capital: '68147.00', interest: '23851.45', stakeId: '279', tx: '0xbf81dccedb345a6d8217c4c03beee6480cd5a2fd8f501010fd6fa2f12a6db86f', status: 'Locked', date: '2025-12-30' },
    ];

    return (
        <div className="space-y-10">
            {/* Header Section */}
            <div className="text-center space-y-4">

                <RevealAnimation delay={0.2}>
                    <p className="text-accent/80 text-base md:text-lg max-w-3xl mx-auto">
                        Maximize your holdings by staking FELY. Earn rewards while contributing to the ecosystem stability.
                    </p>
                </RevealAnimation>
            </div>

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* LEFT COLUMN: Main Staking Card */}
                <div className="space-y-8">
                    {/* 1. Stake Card */}
                    <RevealAnimation delay={0.3}>
                        <div className="bg-secondary dark:bg-background-8 rounded-[30px] p-6 border border-stroke-2 dark:border-stroke-6 overflow-hidden relative h-full">
                            <div className="relative z-10 space-y-6">
                                <div className="text-left">
                                    <h3 className="text-xl font-bold text-white mb-1">Wallet Connection & Staking Actions</h3>
                                </div>

                                {/* Connect Status */}
                                <div className="bg-[#13171E] rounded-xl p-4 border border-[#2a333e] space-y-3">
                                    <h4 className="text-white text-sm font-medium">Connection Status</h4>
                                    <button className="btn btn-primary btn-sm w-auto px-6">
                                        CONNECT WALLET
                                    </button>
                                    <div>
                                        <p className="text-xs text-gray-500">Wallet Address:</p>
                                        <p className="text-xs text-primary-500 font-medium font-mono">Waiting...</p>
                                    </div>
                                </div>

                                {/* Stake Form */}
                                <div className="space-y-4">
                                    <div className="space-y-2">
                                        <label className="text-xs text-gray-300">USDT Amount</label>
                                        <div className="relative">
                                            <input type="number" placeholder="Enter amount" className="w-full bg-[#13171E] border border-[#2a333e] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary-500 placeholder:text-sm" />
                                            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 text-xs">USDT</span>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs text-gray-300">Period</label>
                                        <select className="w-full bg-[#13171E] border border-[#2a333e] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary-500 appearance-none">
                                            <option value="6">6 Months (8% APY)</option>
                                            <option value="12">12 Months (12.5% APY)</option>
                                        </select>
                                    </div>
                                    <button className="btn btn-primary btn-lg w-full shadow-lg shadow-primary-500/20 mt-2">
                                        STAKE
                                    </button>
                                </div>
                            </div>
                        </div>
                    </RevealAnimation>
                </div>

                {/* RIGHT COLUMN: Lookups & Secondary Actions */}
                <div className="space-y-8">
                    {/* 2. Lookup Stake IDs */}
                    <RevealAnimation delay={0.3}>
                        <div className="bg-secondary dark:bg-background-8 rounded-[30px] p-6 border border-stroke-2 dark:border-stroke-6">
                            <div className="space-y-6">
                                <h3 className="text-xl font-bold text-white">Lookup Stake IDs</h3>
                                <div className="flex gap-3">
                                    <input type="text" placeholder="Enter Wallet Address" className="flex-1 bg-[#13171E] border border-[#2a333e] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary-500 min-w-0 placeholder:text-sm" />
                                    <button className="btn btn-primary btn-sm whitespace-nowrap min-w-[100px] px-6">
                                        SEARCH
                                    </button>
                                </div>

                                <div className="pl-1">
                                    <p className="text-gray-400 text-sm">Results: <span className="text-gray-500 italic ml-2">No active stakes found</span></p>
                                </div>
                            </div>
                        </div>
                    </RevealAnimation>

                    {/* 3. Claim Interest */}
                    <RevealAnimation delay={0.4}>
                        <div className="bg-secondary dark:bg-background-8 rounded-[30px] p-6 border border-stroke-2 dark:border-stroke-6">
                            <h3 className="text-xl font-bold text-white mb-4">% Claim Interest</h3>
                            <div className="flex gap-3">
                                <input type="text" placeholder="Enter Stake ID" className="flex-1 bg-[#13171E] border border-[#2a333e] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary-500 min-w-0 placeholder:text-sm" />
                                <button className="btn btn-primary btn-sm whitespace-nowrap min-w-[100px] px-6">
                                    CLAIM
                                </button>
                            </div>
                        </div>
                    </RevealAnimation>

                    {/* 4. Withdraw Capital */}
                    <RevealAnimation delay={0.5}>
                        <div className="bg-secondary dark:bg-background-8 rounded-[30px] p-6 border border-stroke-2 dark:border-stroke-6">
                            <h3 className="text-xl font-bold text-white mb-4">⎋ Withdraw Capital</h3>
                            <div className="flex gap-3">
                                <input type="text" placeholder="Enter Stake ID" className="flex-1 bg-[#13171E] border border-[#2a333e] rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary-500 min-w-0 placeholder:text-sm" />
                                <button className="btn btn-secondary text-white border border-[#2a333e] hover:bg-[#2a333e] btn-sm whitespace-nowrap min-w-[100px] px-6">
                                    WITHDRAW
                                </button>
                            </div>
                        </div>
                    </RevealAnimation>
                </div>
            </div>

            {/* 5. Data Table (Full Width) */}
            <RevealAnimation delay={0.6}>
                <div className="bg-secondary dark:bg-background-8 rounded-[30px] p-6 border border-stroke-2 dark:border-stroke-6 overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="border-b border-[#2a333e]">
                                <th className="p-4 text-white font-semibold whitespace-nowrap">Order No</th>
                                <th className="p-4 text-white font-semibold whitespace-nowrap">Capital</th>
                                <th className="p-4 text-white font-semibold whitespace-nowrap">Interest</th>
                                <th className="p-4 text-white font-semibold whitespace-nowrap">Stake ID</th>
                                <th className="p-4 text-white font-semibold whitespace-nowrap">Transaction #</th>
                                <th className="p-4 text-white font-semibold whitespace-nowrap">Status</th>
                                <th className="p-4 text-white font-semibold whitespace-nowrap">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {stakeData.map((row, i) => (
                                <tr key={i} className="border-b border-[#2a333e] last:border-0 hover:bg-[#13171E]/50 transition-colors">
                                    <td className="p-4 text-gray-300">{row.orderNo}</td>
                                    <td className="p-4 text-gray-300">{row.capital}</td>
                                    <td className="p-4 text-gray-300">{row.interest}</td>
                                    <td className="p-4 text-gray-300">{row.stakeId}</td>
                                    <td className="p-4 text-gray-300 truncate max-w-[200px]" title={row.tx}>{row.tx || '-'}</td>
                                    <td className="p-4">
                                        <span className="inline-block px-2 py-1 bg-primary-500/20 text-primary-500 text-xs rounded-md">
                                            {row.status}
                                        </span>
                                    </td>
                                    <td className="p-4 text-gray-300">{row.date}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </RevealAnimation>
        </div>
    );
};

export default StakeFelySection;
